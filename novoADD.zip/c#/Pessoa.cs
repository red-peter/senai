namespace ClientLab
{

    public class Pessoa
    {
        public string Nome;
        //novas adições
        public string logradouro;
        public int Numero;
        public string Bairro;
    }
}