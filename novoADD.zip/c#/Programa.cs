using System;

namespace ClientLab
{
    class Programa
    {
        static void Main(string[] args)
        {
            Console.WriteLine("....................................");
            Console.WriteLine("    CADASTRO DE CLIENTES CLIENTLAB  ");
            Console.WriteLine("....................................\n");

            // ---PF ---
            Console.WriteLine("--- Cadastro de Pessoa Física ---");
            
            PessoaFisica pf = new PessoaFisica();

            Console.Write("Digite o Nome: ");
            pf.Nome = Console.ReadLine();

            Console.Write("Digite o CPF: ");
            pf.CPF = Console.ReadLine();

            Console.Write("Digite a Data de Nascimento (ex: 15/05/2000): ");
            pf.DataNascimento = DateTime.Parse(Console.ReadLine());

            Console.Write("Digite o Logradouro (Rua/Av): ");
            pf.Logradouro = Console.ReadLine();

            Console.Write("Digite o Número: ");
            pf.Numero = int.Parse(Console.ReadLine());

            Console.Write("Digite o Bairro: ");
            pf.Bairro = Console.ReadLine();

          
            if (pf.EhMaiorDeIdade() == true)
            {
                Console.Write("Digite o Rendimento Mensal (R$): ");
                double rendimentoPF = double.Parse(Console.ReadLine());
                double impostoPF = pf.PagarImposto(rendimentoPF);

                Console.WriteLine("\n--> Sucesso: Pessoa Física cadastrada!");
                Console.WriteLine("Nome: " + pf.Nome + " | CPF: " + pf.CPF);
                Console.WriteLine("Endereço: " + pf.Logradouro + ", " + pf.Numero + " - " + pf.Bairro);
                Console.WriteLine("Imposto a pagar (3%): R$ " + impostoPF);
            }
            else
            {
                Console.WriteLine("\n--> ERRO: O cliente deve ter 18 anos ou mais para se cadastrar!");
            }

            Console.WriteLine("\n------------------------------------\n");

            // --- PJ ---
            Console.WriteLine("--- Cadastro de Pessoa Jurídica ---");

            PessoaJuridica pj = new PessoaJuridica();

            Console.Write("Digite o Nome Fantasia: ");
            pj.Nome = Console.ReadLine();

            Console.Write("Digite a Razão Social: ");
            pj.RazaoSocial = Console.ReadLine();

            Console.Write("Digite o CNPJ: ");
            pj.CNPJ = Console.ReadLine();
             
            Console.Write("Digite o Logradouro (Rua/Av): ");
            pj.Logradouro = Console.ReadLine();

            Console.Write("Digite o Número: ");
            pj.Numero = int.Parse(Console.ReadLine());

            Console.Write("Digite o Bairro: ");
            pj.Bairro = Console.ReadLine();

            
            if (pj.ValidarCNPJ() == true)
            {
                Console.Write("Digite o Rendimento Mensal da Empresa (R$): ");
                double rendimentoPJ = double.Parse(Console.ReadLine());
                double impostoPJ = pj.PagarImposto(rendimentoPJ);

                Console.WriteLine("\n--> Sucesso: Pessoa Jurídica cadastrada!");
                Console.WriteLine("Empresa: " + pj.RazaoSocial + " | CNPJ: " + pj.CNPJ);
                Console.WriteLine("Endereço: " + pj.Logradouro + ", " + pj.Numero + " - " + pj.Bairro);
                Console.WriteLine("Imposto a pagar (5%): R$ " + impostoPJ);
            }
            else
            {
                Console.WriteLine("\n--> ERRO: CNPJ inválido! Deve ter 14 dígitos e conter '0001' antes dos dígitos finais.");
            }

            Console.WriteLine("\nPressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}