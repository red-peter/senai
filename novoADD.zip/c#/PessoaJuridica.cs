namespace ClientLab
{
    public class PessoaJuridica : Pessoa
    {
        public string CNPJ;
        public string RazaoSocial;

        public bool ValidarCNPJ()
        {
            string apenasNumeros = CNPJ.Replace(".", "").Replace("-", "").Replace("/", "");

            if (apenasNumeros.Length != 14)
            {
                return false; 
            }

            string blocoFilial = apenasNumeros.Substring(8, 4);

            if (blocoFilial == "0001")
            {
                return true; 
            }
            else
            {
                return false; 
            }
        }
        public double pagarImposto(double rendimento)
        {
            return rendimento * 0.05;
        }
        public void SalvarEmArquivo(double rendimento)
        {
            string arquivoNome = Nome + ".txt";

           
            string conteudo = "--- DADOS DA PESSOA JURÍDICA ---\n" +
                             "Nome Fantasia: " + Nome + "\n" +
                             "Razão Social: " + RazaoSocial + "\n" +
                             "CNPJ: " + CNPJ + "\n" +
                             "Endereço: " + Logradouro + ", " + Numero + " - " + Bairro + "\n" +
                             "Rendimento: R$ " + rendimento + "\n" +
                             "Imposto (5%): R$ " + PagarImposto(rendimento);

//tudo da parte salvaremarquivo vai se coletado tipo o get do java, e vai ser guardado em um txt
//no caso vai ser guardado  nesse comando abaixo,comando esse que só pega os dados fornecidos e coloca em um arquivo txt
//metodo  bem legal para guardar dados e deixar visivel para o usuario,é só isso..
            File.WriteAllText(arquivoNome, conteudo);
        }
    }
}