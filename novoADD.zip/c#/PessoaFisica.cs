using System;
using System.io;

namespace ClientLab
{
    public class PessoaFisica : Pessoa
    {
        public string CPF;
        public DateTime DataNascimento;
        public bool EhMaiorDeIdade()
        {
            DateTime hoje = DateTime.Today;

            int idade = hoje.Year - DataNascimento.Year;
    
            if (DataNascimento.Date > hoje.AddYears(-idade))
            {
                idade = idade - 1;
            }
            return idade >= 18;
    
        }
        public double pagarImposto(double rendimento)
        {
            return rendimento * 0.03;
        }
        public void SalvarEmArquivo(double rendimento)
        {
           
            string arquivoNome = Nome + ".txt";

      
            string conteudo = "--- DADOS DA PESSOA FÍSICA ---" +
                             "Nome: " + Nome + "\n" +
                             "CPF: " + CPF + "\n" +
                             "Data de Nascimento: " + DataNascimento.ToString("dd/MM/yyyy") + "\n" +
                             "Endereço: " + Logradouro + ", " + Numero + " - " + Bairro + "\n" +
                             "Rendimento: R$ " + rendimento + "\n" +
                             "Imposto (3%): R$ " + PagarImposto(rendimento);

           
            File.WriteAllText(arquivoNome, conteudo);
            //tudo da parte salvaremarquivo vai se coletado tipo o get do java, e vai ser guardado em um txt
//no caso vai ser guardado  nesse comando abaixo,comando esse que só pega os dados fornecidos e coloca em um arquivo txt
//metodo  bem legal para guardar dados e deixar visivel para o usuario,é só isso..
//obs:esses comentarios também estaŕa na pessoa juridica,coloquei aqui também porque pode ser visto aqwui primeiro
//continuando...ou no outro arquivo
        }
    }
}